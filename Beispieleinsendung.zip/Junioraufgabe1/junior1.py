#!/usr/bin/python

print("Junioraufgabe 1")
