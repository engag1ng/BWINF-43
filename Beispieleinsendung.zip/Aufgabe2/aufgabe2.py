#!/usr/bin/python

print("Aufgabe 2")
